

#' Get hex color ids for EPFL corporate colors
#'
#' @param name vector containing the color names (see below). If no name is supplied, then the whole color dataframe with two
#' color names and the hex code is returned.
#' @param message logical, displays the note from EPFL corporate identity.
#'
#' @details Color names are: \code{"dark-red"}, \code{"red"},
#' \code{"dark-blue"}, \code{"blue"},  \code{"dark-green"}, \code{"green"},
#' \code{"dark-gray"}, \code{"gray"}, or the the official names \code{"groseille"},
#' \code{"rouge"}, \code{"canard"}, \code{"leman"}, \code{"ardoise"},
#' \code{"perle"}.
#'
#' @references Source: \href{https://www.epfl.ch/campus/services/communication/wp-content/uploads/2019/03/EPFL-brand-guidelines.pdf}{EPFL Brand Guidelines}
#'
#' @return Named character vector or dataframe.
#' @export
#'
#' @examples
#' epfl_corp_color()
#' epfl_corp_color("blue")
#' epfl_corp_color("green")
#' epfl_corp_color("green", message = TRUE)
#'
epfl_corp_color <- function(name = NULL, message = FALSE)
{

  #color_mat <- tibble::tribble(
  #  ~epfl_color_name, ~human_color_name, ~hex,
  #  "groseille", "dark-red", "#B51F1F" ,
  #  "rouge", "red", "#FF0000"    ,
  #  "canard", "dark-blue", "#007480" ,
  #  "leman", "blue", "#00A79F"   ,
  #  "ardoise", "dark-gray", "#413D3A"  ,
  #  "perle", "gray", "#CAC7C7"
  #)

  color_mat <- structure(
    list(
      epfl_color_name = c("groseille", "rouge", "canard", "leman", "ardoise", "perle"),
      human_color_name = c("dark-red", "red", "dark-blue", "blue", "dark-gray", "gray"),
      hex = c("#B51F1F", "#FF0000", "#007480", "#00A79F", "#413D3A", "#CAC7C7")),
    row.names = c(NA, -6L), class = c("tbl_df", "tbl", "data.frame"))

  ## repeat lines that are blue for greed
  color_mat_green <- color_mat[grep("blue", color_mat$human_color_name), ]
  color_mat_green$human_color_name <- gsub("blue", "green", color_mat_green$human_color_name)

  color_mat <- rbind(color_mat, color_mat_green)

  color_mat_long <- stats::reshape(as.data.frame(color_mat), varying = list(1:2), direction = "long")[, c("epfl_color_name", "hex")]


  if (message) message("EPFL corp id:\n\nUsing colors appropriately is one of the easiest ways to ensure that our documents reflect a coherent visual image or story from EPFL.\n\nAlways balance colors with generous white spaces.
")

  if(is.null(name))
  {
    return(color_mat)
  } else {

    if(any(color_mat_long$epfl_color_name %in% name))
    {
      out <- sapply(name, function(x) color_mat_long[color_mat_long$epfl_color_name == x, "hex"])
    }else {
      stop("The color you choose is not an EPFL color.")
    }

    return(out)

  }


}
