test_that("Correct color name returns character in the correct order. ", {
  out <- epfl_corp_color(c("red", "dark-red"))

  expect_equal(class(out), "character")

  expect_identical(out, c(red = "#FF0000", `dark-red` = "#B51F1F"))

})

test_that("wrong name returns error message", {

    expect_error(epfl_corp_color("pink"), "The color you choose is not an EPFL color.")

})

test_that("no name returns data frame", {

  expect_equal(dim(epfl_corp_color()), c(8, 3))

})

