library(testthat)
library(EPFLcorpid)

test_check("EPFLcorpid")
