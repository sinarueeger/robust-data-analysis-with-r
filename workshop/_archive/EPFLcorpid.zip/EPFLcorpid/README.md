
<!-- README.md is generated from README.Rmd. Please edit that file -->

# EPFLcorpid

<!-- badges: start -->

<!-- badges: end -->

The goal of EPFLcorpid is to …

## Installation

You can install the released version of EPFLcorpid from
[CRAN](https://CRAN.R-project.org) with:

``` r
install.packages("EPFLcorpid")
```

And the development version from [GitHub](https://github.com/) with:

``` r
# install.packages("devtools")
devtools::install_github("sinarueeger/EPFLcorpid")
```

## Example

This is a basic example which shows you how to solve a common problem:

``` r
library(EPFLcorpid)

## Display all colors
epfl_corp_color()
#>    epfl_color_name human_color_name     hex
#> 1        groseille         dark-red #B51F1F
#> 2            rouge              red #FF0000
#> 3           canard        dark-blue #007480
#> 4            leman             blue #00A79F
#> 5          ardoise        dark-gray #413D3A
#> 6            perle             gray #CAC7C7
#> 31          canard       dark-green #007480
#> 41           leman            green #00A79F

## Only blue (or green)
epfl_corp_color("blue")
#>      blue 
#> "#00A79F"
epfl_corp_color("green")
#>     green 
#> "#00A79F"

## Red
epfl_corp_color(c("red", "dark-red"))
#>       red  dark-red 
#> "#FF0000" "#B51F1F"

epfl_corp_color("green", message = TRUE)
#> EPFL corp id:
#> 
#> Using colors appropriately is one of the easiest ways to ensure that our documents reflect a coherent visual image or story from EPFL.
#> 
#> Always balance colors with generous white spaces.
#>     green 
#> "#00A79F"
```
